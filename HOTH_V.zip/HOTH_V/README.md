# Password Generator Basic 

### authors: David Zhao, Roy Shao, and Hamlin Liu


Basic Password Generator that asks for length of the password and certain character limitations


Run PasswordGenerator.html to use the program
